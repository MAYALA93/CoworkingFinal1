package com.coworking.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.coworking.demo.entity.Administrateur;
import com.coworking.demo.entity.User;
import com.coworking.demo.repository.AdministrateurRepository;
import com.coworking.demo.repository.UserRepository;



@RunWith(SpringRunner.class)
@SpringBootTest
public class CoworkingBossApplicationTests {

	
	@Autowired
	UserRepository users;
    
	@Test
	public void UserTest(){
 
  User Michel = new User("Michel", "Folon", "Folon94", "963IJK", "michelfolon@gmail.com","6 rue de laval 93254 SEVRAN", "Entreprise GANA");
  User.save(Michel);
  
	}
	

@Autowired
AdministrateurRepository admins;

@Test
public void AdministrateurTest(){

Administrateur Carine = new Administrateur("MPAKA carine", "147EFG");
Administrateur.save(Carine);

	}
}
