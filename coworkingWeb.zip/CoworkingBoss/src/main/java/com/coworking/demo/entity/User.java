package com.coworking.demo.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="coworkingboss.user")

public class User {

	protected User() {
	
	}
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
        private String username;
        private String prenom;
		private String nom;
		private String password;
		private String email;
		private String adresse;
		private String societe;

		public User(String nom, String prenom, String email, String adresse, String societe, String username, String password) {
			this.nom = nom;
			this.prenom = prenom;
			this.email = email;
			this.username = username;
			this.password = password;
			this.adresse = adresse;
			this.societe=societe;
		}
		
		
        
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		public String getNom() {
			return nom;
		}

		public void setNom(String nom) {
			this.nom = nom;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

	     public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getprenom() {
		return prenom;
	}

	public void setprenom(String prenom) {
		this.prenom = prenom;
	}



	public static void save(User michel) {
		
	}



	public String getAdresse() {
		return adresse;
	}



	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}



	public String getSociete() {
		return societe;
	}



	public void setSociete(String societe) {
		this.societe = societe;
	}



	public void setId() {
		// TODO Auto-generated method stub
		
	}

 public void createUser() {
	 
 }

	public void add(User user) {
		// TODO Auto-generated method stub
		
	}

		}


