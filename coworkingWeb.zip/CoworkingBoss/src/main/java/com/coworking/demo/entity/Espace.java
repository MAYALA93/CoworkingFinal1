package com.coworking.demo.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name= "coworkingboss.espace")
public class Espace {
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String libelle;
 
   
    
    protected Espace() {
	}
    
    
  


	public Espace(String libelle) {
		this.libelle = libelle;
    }
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public static List<Espace> listerEspaces() {
		// TODO Auto-generated method stub
		return null;
	}
	public int getEspaceId() {
		// TODO Auto-generated method stub
		return 0;
	}
	public static void save(Espace lonovo) {
		// TODO Auto-generated method stub
		
	}
}
