package com.coworking.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coworking.demo.entity.Administrateur;

public interface AdministrateurRepository extends JpaRepository<Administrateur, Long>{


}
