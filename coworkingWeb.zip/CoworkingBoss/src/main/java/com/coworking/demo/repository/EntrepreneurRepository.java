package com.coworking.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coworking.demo.entity.Entrepreneur;


	public interface EntrepreneurRepository extends JpaRepository<Entrepreneur, Long>{ 
		
	}

