package com.coworking.demo.controller;




	import java.util.List;
	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.coworking.demo.entity.User;
	import com.coworking.demo.repository.UserRepository;


	@CrossOrigin(maxAge = 3600)
	@RestController
	@RequestMapping(value = "/coworkingboss")
	public class UserController {


		
		
		@Autowired
		private UserRepository userRepo;
		
		@CrossOrigin(origins = "http://localhost:8115/")
		@GetMapping(value = "/user/{id}")
		public Optional<User> getUser (@PathVariable ("id") Long id) {
		    return userRepo.findById(id);
		}	
		
		@GetMapping(value ="/user")
		  public List<User> list() {
		  return userRepo.findAll();
		}

		@PostMapping(value = "/user")
		    public String createUser(@RequestBody User newUser) {                              
			User userbyusername = userRepo.findByUsername(newUser.getUsername());
			User userbyemail = userRepo.findByEmail(newUser.getEmail());
			if((userbyusername == null) && (userbyemail == null)) {
				
			 userRepo.save(newUser);
			 
		
		}
			
			return "creation user reussie";
					 
		}
	
			
		
		 
		@PutMapping(value = "/user/{id}")
		public String updateUser(@PathVariable Long id, @RequestBody User user) {
			Optional<User> userone = userRepo.findById(id);
			if(userone.isPresent()) {
				userone.get().setNom(userone.get().getNom());
				userone.get().setEmail(userone.get().getEmail());
				userone.get().setAdresse(userone.get().getAdresse());
	            userone.get().setPassword(userone.get().getPassword());
				
	            userRepo.save(userone.get());
				return "mise a jour user reussie";
				 
			}
			throw new RuntimeException("user is not available!!");
		}
			
		  

	 	@DeleteMapping(value = "/user/delete/{id}")
			public ResponseEntity<?> deleteUser(@PathVariable Long id, @RequestBody User user) {
				Optional<User> usersearch = userRepo.findById(id);
				userRepo.delete(usersearch.get());
				return ResponseEntity.ok().build();
			
				
			//throw new RuntimeException("account is not be deleted!!");

				
	}	
	
}
